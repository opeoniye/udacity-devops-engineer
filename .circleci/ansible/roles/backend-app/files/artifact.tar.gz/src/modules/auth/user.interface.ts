export interface User {
  username: string;
}
